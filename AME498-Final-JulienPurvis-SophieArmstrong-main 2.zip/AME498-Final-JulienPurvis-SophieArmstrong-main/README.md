CONTENTS:

Arduino Code: A modified version of the Xinyuan-LilyGo/T-Wristband-MPU9250 Example https://github.com/Xinyuan-LilyGO/T-Wristband/tree/master/examples#:~:text=last%20year-,T%2DWristband%2DMPU9250,-perfect%3A%20Optimize%20apply_patch

Server Code: A modified version of the tejaswigowda/ame498-598Fall2023-CaptureDataServer-Accel 
https://github.com/tejaswigowda/ame498-598Fall2023/tree/main/watchSensors#:~:text=captureDataServer%2DAccel
